﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            double sum = 0.0;
            double invalidsum = 0.0;
            double iChoice = 0.0;
            Console.WriteLine("Vending Machine");
            Console.Write("Enter Your Coin Amount: ");
            iChoice = Convert.ToDouble(Console.ReadLine());
            while (iChoice != 0.0)
            {
                
                double value = calculate(iChoice);
                if (value == Constants.CoinOnenickels || value == Constants.Cointwodimes || value == Constants.Cointhreequarters)
                {
                    sum = sum + value;
                    Console.Write("Total Valid Coin Amount =" +sum+'$');
                    Console.Write("\n Enter Your Coin Amount:");
                    iChoice = Convert.ToDouble(Console.ReadLine());
                }
                else
                {
                    Console.Write("invalid coin \n");
                    Console.Write("Insert valid coin \n");
                    invalidsum = invalidsum + value;
                    Console.Write("Total Invalid Coin Amount =" + invalidsum + '$');
                    Console.Write("\n Enter Your Coin Amount:");
                    iChoice = Convert.ToDouble(Console.ReadLine());
                    
                }
                
                
            }
        }
        private static double calculate(double iChoice)
        {
            double sum = 0.0;
            if (iChoice == Constants.CoinOnenickels || iChoice == Constants.Cointwodimes || iChoice == Constants.Cointhreequarters)
            {
                switch (iChoice)
                {
                    case Constants.CoinOnenickels:
                        sum = 0.05;
                        break;
                    case Constants.Cointwodimes:
                        sum = 0.1;
                        break;
                    case Constants.Cointhreequarters:
                        sum = 0.25;
                        break;
                }

            }
            else
            {
                sum = iChoice;
            }
            return sum;
        }
        static class Constants
        {
            public const double CoinOnenickels = 0.05;
            public const double Cointwodimes = 0.1;
            public const double Cointhreequarters = 0.25;
        }
    }
    
}
