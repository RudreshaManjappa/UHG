﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            string iChoice = "";
            Console.WriteLine("Vending Machine");
            Console.Write("Enter your coin: ");
            iChoice = Convert.ToString(Console.ReadLine());
            while (iChoice != "0")
            {
                
                int value = calculate(iChoice);
                if (value != 0)
                {
                    sum = sum + value;
                    Console.Write("Total Amount =" +sum+'$');
                    Console.Write("\n Enter your coin:");
                    iChoice = Convert.ToString(Console.ReadLine());
                }
                else
                {
                    Console.Write("invalid coin \n");
                    Console.Write("Insert valid coin \n");
                    Console.Write("\n Enter your coin:");
                    iChoice = Convert.ToString(Console.ReadLine());
                    
                }
                
                
            }
        }
        private static int calculate(string iChoice)
        {
            int sum = 0;
            if (iChoice == Constants.CoinOne || iChoice == Constants.Cointwo || iChoice == Constants.Cointhree)
            {
                switch (iChoice)
                {
                    case Constants.CoinOne:
                        sum = 20;
                        break;
                    case Constants.Cointwo:
                        sum = 10;
                        break;
                    case Constants.Cointhree:
                        sum = 4;
                        break;
                    default:
                        sum = 0;
                        break;
                }

            }
            return sum;
        }
        static class Constants
        {
            public const string CoinOne = "nickels";
            public const string Cointwo = "dimes";
            public const string Cointhree = "quarters";
        }
    }
    
}
